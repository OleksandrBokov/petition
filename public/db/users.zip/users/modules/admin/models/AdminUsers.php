<?php


class AdminUsers extends User
{

    public $new_password;

    public function init()
    {
        $this->role = User::ROLE_MANAGER;
    }

    public function rules()
    {
        return array(
            array('password, email', 'required'),
            array('email','email'),
            array('created_at, status', 'numerical', 'integerOnly'=>true),

            array('new_password', 'length', 'max'=>100),
            array('firstName, lastName', 'safe'),
            array('email', 'unique','message'=>Yii::t('app','A user with this email already exists.')),

            array('id, email, password, new_password, firstName, lastName, created_at, token, role, status', 'safe', 'on'=>'search'),
        );
    }

    protected function beforeSave()
    {
        if($this->isNewRecord){

            $m = new Mail();
            $message = $m->createMessage($this, 'account_create');
            MailHeler::_createMailToHtml($message);

            $this->created_at = DateHelper::setCurrentDateTimeToTimestamp();
            $this->password = CPasswordHelper::hashPassword($this->password);

            Logs::model()->createRecord(['message'=>Yii::t('app', 'New user created : username',array('username'=>$this->email)),'actions'=>'created user']);
        }

        return parent::beforeSave();
    }



    public function updateUser($old_email, $old_status, $model)
    {
        if($old_email != $model->email){
            Logs::model()->createRecord(['message'=>Yii::t('app', 'E-mail of old_email has been changed to email',array('old_email'=>$old_email, 'email'=>$model->email)),
            'actions'=>'change email']);
        }

        if($old_status != $model->status)
        {
            $m = new Mail();
            $message = $m->createMessage($model, 'account_change_status');
             MailHeler::_createMailToHtml($message);

            Logs::model()->createRecord(['message'=>Yii::t('app','The status of the username user account has been changed to status',
                array('username'=>$model->email, 'status'=>Yii::t('app','n==0#not_authorized|n==1#authorized|n==2#blocked',$model->status))), 'actions'=>'change status']);
        }

        if(!empty($model->new_password))
        {
            $m = new Mail();
            $message = $m->createMessage($model, 'reset_password');

            MailHeler::_createMailToHtml($message);

            Logs::model()->createRecord(['message'=>Yii::t('app','The username password was changed',array('username'=>$model->email)), 'actions'=>'reset password']);

            $model->password = CPasswordHelper::hashPassword($model->new_password);
        }

        if($model->save())
            return true;
        else
            throw new CHttpException(404, $model->getErrors());
    }

    public function deleteUser($model)
    {
        if($model->delete()){
            Logs::model()->createRecord(['message'=>Yii::t('app', 'Аккаунт пользователя username был удален',array('username'=>$model->email)), 'actions'=>'delete user']);
            return true;
        }
    }
    /**
     * Returns the static model of the specified AR class.
     * Please note that you should have this exact method in all your CActiveRecord descendants!
     * @param string $className active record class name.
     * @return User the static model class
     */
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
}